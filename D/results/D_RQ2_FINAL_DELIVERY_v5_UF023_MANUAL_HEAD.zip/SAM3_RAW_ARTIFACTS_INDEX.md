# SAM3 원시 마스크·상태 자료 안내

원시 SAM3 산출물은 파일 수와 용량 때문에 최종 전달 폴더 안에 중복 업로드하지 않고, GPU 담당자가 올린 Drive 폴더에 보존되어 있다.

- [SAM3 실행 폴더](https://drive.google.com/drive/folders/1jLZPPulChwUD2li7u0F8tgwoBB5puygR)
- 하위 폴더 `sam3_test_masks`: 101개 TEST 이미지의 `.npz` 마스크, `mask_index.csv`, `mask_status.json`
- 하위 폴더 `sam3_masked_images`: 개 전체 마스크 적용 이미지
- 하위 폴더 `sam3_head_masked_images`: 머리 마스크 적용 이미지

로컬 전달본에는 재현·검증에 필요한 `mask_index.csv`와 `mask_status.json`을 포함한다. 원시 `.npz` 전체는 위 Drive 하위 폴더를 기준으로 확인한다.

주의: `mask_status.json`에는 수동 머리 박스 개수 필드가 없고, `mask_index.csv`에도 수동/자동 출처 열이 없다. 따라서 `D_manual_head_box_count.csv`에는 숫자를 추정하지 않고 `not_explicitly_recorded`로 기록했다. `UF023`은 `head_area=0`이므로 최종 보고서에서 머리 마스크 예외 사례로 표시해야 한다.
