# D: RQ2 단서 분석 최종 완료 보고서

## 결론

최종 합의된 범위에서는 D파트를 완료했다. 최종 범위는 DINOv3 matched-control 변형 실험, SIFT matched-control 보완 실험, 새 TEST셋 통합, SAM3 개/머리 마스크 기반 평가다.

원래 초안에 있던 배경-only 실험, 선택실험(어텐션 그림 포함)은 진행하지 않기로 한 결정에 따라 제외했다. 따라서 이 패키지에서 `excluded`는 누락이 아니라 최종 범위에서 의도적으로 제외된 항목이다.

## 완료된 산출물

- DINOv3: `orig / gray / blur1 / blur3 / blur6 / blur12`와 `panel_face / panel_body`, A 분류기 seed 1·2·3.
  - manifest 300행, 상세 900행, extra-drop 상세 420행, 요약 189행.
- SIFT: C파트의 `sift_codebook.npy`와 SIFT 분류기 seed 1·2·3을 사용해 `gray / blur1 / blur3 / blur6 / blur12`와 PSNR matched-control을 재실행.
  - 20개 평가 이미지, 입력 220장, control score 1,980행, extra-drop 상세 900행, 요약 45행.
  - 흑백 sanity check는 PASS.
- 새 TEST셋: CLIP·DINOv2·DINOv3 통합 결과 909행, 요약 18행.
- SAM3: 101개 TEST 이미지의 마스크/상태와 body/head masked DINOv3 결과 각 303행.
- `UF089_2` 매칭은 재확인 결과 `matched=True`.

## 해석 범위

이 패키지의 DINOv3와 SIFT 표·그래프가 최종 단서 분석 결과다. CLIP·DINOv2는 최종 TEST 통합 참고 결과로 포함했지만, 이번 최종 합의 범위에서 이 두 추출기의 matched-control extra-drop을 새로 재실행하지 않았다.

## 제외 항목

- background-only 변형
- 선택실험
- 선택실험에 해당하는 attention 그림
- SIFT의 panel_face/panel_body 영역 변형

상태와 행 수의 근거는 `D_RQ2_FINAL_VERIFICATION.json`과 `D_RQ2_completion_audit.csv`에 기록했다.
